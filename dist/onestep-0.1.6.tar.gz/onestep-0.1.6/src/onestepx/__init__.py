from .core import collapse_to_terminal, TERMINAL

__all__ = ["collapse_to_terminal", "TERMINAL"]
